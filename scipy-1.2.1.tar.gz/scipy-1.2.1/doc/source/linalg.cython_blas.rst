.. automodule:: scipy.linalg.cython_blas
