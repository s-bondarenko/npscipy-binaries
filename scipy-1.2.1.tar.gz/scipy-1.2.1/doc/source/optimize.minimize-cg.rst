.. _optimize.minimize-cg:

minimize(method='CG')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize.optimize._minimize_cg
   :method: CG
