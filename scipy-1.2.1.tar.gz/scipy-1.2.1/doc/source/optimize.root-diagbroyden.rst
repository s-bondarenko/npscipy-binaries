.. _optimize.root-diagbroyden:

root(method='diagbroyden')
--------------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_diagbroyden_doc
   :method: diagbroyden
