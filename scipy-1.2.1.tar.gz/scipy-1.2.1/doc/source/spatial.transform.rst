.. automodule:: scipy.spatial.transform
