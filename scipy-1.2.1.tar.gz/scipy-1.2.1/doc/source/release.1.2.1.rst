.. include:: ../release/1.2.1-notes.rst
