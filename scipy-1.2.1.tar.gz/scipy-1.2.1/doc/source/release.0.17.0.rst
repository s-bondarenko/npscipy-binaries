.. include:: ../release/0.17.0-notes.rst
