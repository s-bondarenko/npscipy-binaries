.. automodule:: scipy.interpolate
