.. _optimize.root_scalar-brentq:

root_scalar(method='brentq')
----------------------------

.. scipy-optimize:function:: scipy.optimize.root_scalar
   :impl: scipy.optimize._root_scalar._root_scalar_brentq_doc
   :method: brentq

