.. automodule:: scipy.special.cython_special
